// src/content/siteAdapters/chatgptAdapter.ts
var chatgptAdapter = {
  name: "ChatGPT",
  /**
   * 判断是否是 ChatGPT 对话页面
   */
  isSupported(location) {
    const { hostname, pathname } = location;
    const isChatGPT = hostname === "chatgpt.com" || hostname === "chat.openai.com";
    const isConversationPage = pathname === "/" || pathname.startsWith("/c/");
    return isChatGPT && isConversationPage;
  },
  /**
   * 获取页面中所有的「用户问题 + AI 回答」配对
   * 
   * 改进逻辑：
   * 1. 以用户问题 (role=user) 为核心锚点
   * 2. 只要找到用户问题，就生成一个条目
   * 3. 尝试在用户问题后面寻找对应的 AI 回答，如果找不到也不影响节点生成
   */
  getPromptAnswerPairs(root) {
    const pairs = [];
    const getTopOffset = (element) => {
      const rect = element.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      return rect.top + scrollTop;
    };
    const extractText = (element) => {
      return element.textContent?.trim().replace(/\s+/g, " ") || "";
    };
    const isValidNode = (element) => {
      if (element.querySelector("textarea") || element.querySelector('[contenteditable="true"]') || element.querySelector("form")) {
        return false;
      }
      const text = extractText(element);
      if (text.length < 1) {
        return false;
      }
      return true;
    };
    const allMessages = Array.from(root.querySelectorAll("[data-message-author-role]"));
    const userMessages = allMessages.filter(
      (el) => el.getAttribute("data-message-author-role") === "user" && el instanceof HTMLElement && isValidNode(el)
    );
    userMessages.forEach((userMsg, index) => {
      const promptText = extractText(userMsg);
      const msgIndex = allMessages.indexOf(userMsg);
      let answerNode = userMsg;
      for (let i = msgIndex + 1; i < allMessages.length; i++) {
        const nextMsg = allMessages[i];
        const role = nextMsg.getAttribute("data-message-author-role");
        if (role === "assistant") {
          answerNode = nextMsg;
          break;
        } else if (role === "user") {
          break;
        }
      }
      pairs.push({
        id: `pair-${index}-${Date.now()}`,
        promptNode: userMsg,
        promptText,
        answerNode,
        // 如果没找到回答，这里就是 promptNode 自身
        topOffset: getTopOffset(userMsg)
        // 关键：位置以 prompt 为准
      });
    });
    return pairs;
  },
  /**
   * 快速获取问题数量
   */
  getPromptCount(root) {
    const allUserRoles = root.querySelectorAll('[data-message-author-role="user"]');
    let count = 0;
    for (let i = 0; i < allUserRoles.length; i++) {
      const el = allUserRoles[i];
      if (el.querySelector("textarea") || el.querySelector("form")) {
        continue;
      }
      count++;
    }
    return count;
  }
};

// src/content/siteAdapters/claudeAdapter.ts
var claudeAdapter = {
  name: "Claude",
  isSupported(location) {
    return location.hostname === "claude.ai" || location.hostname.endsWith(".claude.ai");
  },
  getPromptAnswerPairs(root) {
    const pairs = [];
    const userMessages = Array.from(root.querySelectorAll([
      ".font-user-message",
      // 常见类名
      '[data-testid="user-message"]',
      // 测试 ID
      "div.group.grid.grid-cols-1"
      // 某些版本的容器
    ].join(","))).filter((el) => {
      return el.textContent && el.textContent.trim().length > 0;
    });
    userMessages.forEach((msg, index) => {
      const element = msg;
      const rect = element.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const topOffset = rect.top + scrollTop;
      pairs.push({
        id: `claude-turn-${index}`,
        promptNode: element,
        promptText: element.textContent?.trim() || "",
        answerNode: element,
        // 暂时指向自己，跳转逻辑主要依赖 promptNode
        topOffset
      });
    });
    return pairs;
  },
  /**
   * 快速获取问题数量
   */
  getPromptCount(root) {
    const selectors = [
      ".font-user-message",
      // 常见类名
      '[data-testid="user-message"]',
      // 测试 ID
      "div.group.grid.grid-cols-1"
      // 某些版本的容器
    ].join(",");
    const elements = root.querySelectorAll(selectors);
    let count = 0;
    for (let i = 0; i < elements.length; i++) {
      const el = elements[i];
      if (el.textContent && el.textContent.trim().length > 0) {
        count++;
      }
    }
    return count;
  }
};

// src/content/siteAdapters/geminiAdapter.ts
var geminiAdapter = {
  name: "Gemini",
  isSupported(location) {
    return location.hostname === "gemini.google.com";
  },
  getPromptAnswerPairs(root) {
    const pairs = [];
    const userSelectors = [
      "user-query",
      // 标签名
      ".user-query",
      // 类名
      '[data-test-id="user-query"]'
      // 属性
    ];
    const userMessages = Array.from(root.querySelectorAll(userSelectors.join(",")));
    userMessages.forEach((msg, index) => {
      const element = msg;
      const rect = element.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const topOffset = rect.top + scrollTop;
      pairs.push({
        id: `gemini-turn-${index}`,
        promptNode: element,
        promptText: element.textContent?.trim() || "",
        answerNode: element,
        topOffset
      });
    });
    return pairs;
  },
  /**
   * 快速获取问题数量
   */
  getPromptCount(root) {
    const userSelectors = [
      "user-query",
      // 标签名
      ".user-query",
      // 类名
      '[data-test-id="user-query"]'
      // 属性
    ];
    return root.querySelectorAll(userSelectors.join(",")).length;
  }
};

// src/content/siteAdapters/deepseekAdapter.ts
var deepseekAdapter = {
  name: "DeepSeek",
  isSupported(location) {
    return location.hostname === "chat.deepseek.com";
  },
  getPromptAnswerPairs(root) {
    const pairs = [];
    const userMessages = Array.from(root.querySelectorAll([
      "div[data-um-id]",
      ".ds-user-message",
      ".user-message",
      '[role="user"]',
      'div[class*="message"][class*="user"]',
      // 尝试模糊匹配
      ".ds-chat-message-user",
      // 另一种可能
      ".chat-message-user"
    ].join(",")));
    if (userMessages.length === 0) {
      const chatgptLike = root.querySelectorAll('[data-message-author-role="user"]');
      if (chatgptLike.length > 0) {
        userMessages.push(...Array.from(chatgptLike));
      }
    }
    userMessages.forEach((msg, index) => {
      const element = msg;
      const rect = element.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const topOffset = rect.top + scrollTop;
      pairs.push({
        id: `deepseek-turn-${index}`,
        promptNode: element,
        promptText: element.textContent?.trim() || "",
        answerNode: element,
        topOffset
      });
    });
    return pairs;
  },
  /**
   * 快速获取问题数量
   */
  getPromptCount(root) {
    const selectors = [
      "div[data-um-id]",
      ".ds-user-message",
      ".user-message",
      '[role="user"]',
      'div[class*="message"][class*="user"]',
      ".ds-chat-message-user",
      ".chat-message-user",
      '[data-message-author-role="user"]'
    ].join(",");
    return root.querySelectorAll(selectors).length;
  }
};

// src/content/siteAdapters/index.ts
var adapters = [
  chatgptAdapter,
  claudeAdapter,
  geminiAdapter,
  deepseekAdapter
];
function getActiveAdapter(location, customUrls = []) {
  for (const adapter of adapters) {
    if (adapter.isSupported(location)) {
      return adapter;
    }
  }
  if (customUrls.length > 0) {
    const hostname = location.hostname;
    if (customUrls.some((url) => hostname === url || hostname.endsWith("." + url))) {
      const customAdapter = Object.create(chatgptAdapter);
      customAdapter.name = "Custom Site (ChatGPT Compatible)";
      customAdapter.isSupported = () => true;
      return customAdapter;
    }
  }
  return null;
}

// src/content/navigation/answerIndexManager.ts
var AnswerIndexManager = class {
  constructor(adapter, root) {
    this.items = [];
    this.currentIndex = 0;
    // 位置缓存，减少getBoundingClientRect调用
    this.positionCache = /* @__PURE__ */ new Map();
    this.CACHE_VALIDITY_MS = 500;
    // 缓存有效期500ms
    this.intersectionObserver = null;
    this.onIndexChangeCallback = null;
    // 是否允许滚动更新（默认为 true）
    this.scrollUpdateEnabled = true;
    this.adapter = adapter;
    this.root = root;
    this.refresh();
  }
  /**
   * 设置是否允许滚动更新索引
   * 当点击导航时，应暂时禁用，以防止滚动过程中触发错误的索引更新
   */
  setScrollUpdateEnabled(enabled) {
    this.scrollUpdateEnabled = enabled;
  }
  /**
   * 注册索引变更回调
   */
  onIndexChange(callback) {
    this.onIndexChangeCallback = callback;
  }
  /**
   * 刷新对话配对列表
   * 重新查找所有 Prompt-Answer 配对并更新索引
   */
  refresh() {
    const pairs = this.adapter.getPromptAnswerPairs(this.root);
    this.items = pairs.map((pair) => ({
      ...pair
      // relativePosition 稍后在需要时计算
    }));
    this.items.sort((a, b) => a.topOffset - b.topOffset);
    this.updateRelativePositions();
    this.positionCache.clear();
    this.initIntersectionObserver();
  }
  /**
   * 初始化 IntersectionObserver 以替代 scroll 事件轮询
   */
  initIntersectionObserver() {
    if (this.intersectionObserver) {
      this.intersectionObserver.disconnect();
    }
    this.intersectionObserver = new IntersectionObserver((entries) => {
      if (!this.scrollUpdateEnabled)
        return;
      const intersectingEntries = entries.filter((e) => e.isIntersecting);
      if (intersectingEntries.length > 0) {
        let targetIndex = -1;
        for (const entry of intersectingEntries) {
          const index = parseInt(entry.target.dataset.llmNavIndex || "-1");
          if (index > targetIndex) {
            targetIndex = index;
          }
        }
        if (targetIndex !== -1) {
          this.setCurrentIndex(targetIndex);
          if (this.onIndexChangeCallback) {
            this.onIndexChangeCallback(targetIndex);
          }
        }
      }
    }, {
      // 触发区域：视口中间偏上的位置 (45% ~ 50%)
      // 这样当标题滚到屏幕中间时触发高亮
      rootMargin: "-45% 0px -50% 0px",
      threshold: 0
    });
    this.items.forEach((item, index) => {
      if (item.promptNode) {
        item.promptNode.dataset.llmNavIndex = String(index);
        this.intersectionObserver.observe(item.promptNode);
      }
    });
  }
  /**
   * 更新所有条目的相对位置（用于时间线节点位置映射）
   */
  updateRelativePositions() {
    const documentHeight = document.documentElement.scrollHeight || document.body.scrollHeight || 1e3;
    this.items.forEach((item) => {
      if (this.items.length === 1) {
        item.relativePosition = 0;
      } else {
        item.relativePosition = item.topOffset / documentHeight;
      }
    });
  }
  /**
   * 计算元素相对于文档顶部的偏移量
   */
  getTopOffset(element) {
    const rect = element.getBoundingClientRect();
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return rect.top + scrollTop;
  }
  /**
   * 获取所有 Prompt-Answer 条目
   */
  getItems() {
    return this.items;
  }
  /**
   * 获取对话配对总数
   */
  getTotalCount() {
    return this.items.length;
  }
  /**
   * 获取当前索引（从 0 开始）
   */
  getCurrentIndex() {
    return this.currentIndex;
  }
  /**
   * 设置当前索引
   * @param index - 新的索引值（从 0 开始）
   */
  setCurrentIndex(index) {
    if (this.items.length === 0) {
      this.currentIndex = 0;
      return;
    }
    if (index < 0) {
      this.currentIndex = 0;
    } else if (index >= this.items.length) {
      this.currentIndex = this.items.length - 1;
    } else {
      this.currentIndex = index;
    }
  }
  /**
   * 根据索引获取条目
   * @param index - 索引值（从 0 开始）
   * @returns 对应的条目，如果索引无效则返回 null
   */
  getItemByIndex(index) {
    if (index < 0 || index >= this.items.length) {
      return null;
    }
    return this.items[index];
  }
  /**
   * 获取当前条目
   */
  getCurrentItem() {
    return this.getItemByIndex(this.currentIndex);
  }
  /**
   * 获取指定索引的节点（兼容旧接口）
   * @param index - 索引值（从 0 开始）
   * @returns 对应的问题节点，如果索引无效则返回 null
   * @deprecated 建议使用 getItemByIndex 获取完整条目信息
   */
  getNodeByIndex(index) {
    const item = this.getItemByIndex(index);
    return item ? item.promptNode : null;
  }
  /**
   * 获取当前节点（兼容旧接口）
   * @deprecated 建议使用 getCurrentItem 获取完整条目信息
   */
  getCurrentNode() {
    return this.getNodeByIndex(this.currentIndex);
  }
  /**
   * 跳转到上一个对话
   * @returns 是否成功跳转（如果已经是第一个则返回 false）
   */
  moveToPrev() {
    if (this.currentIndex > 0) {
      this.setCurrentIndex(this.currentIndex - 1);
      return true;
    }
    return false;
  }
  /**
   * 跳转到下一个对话
   * @returns 是否成功跳转（如果已经是最后一个则返回 false）
   */
  moveToNext() {
    if (this.currentIndex < this.items.length - 1) {
      this.setCurrentIndex(this.currentIndex + 1);
      return true;
    }
    return false;
  }
  /**
   * 获取节点的缓存位置信息（如果缓存有效）
   * @param index - 节点索引
   * @returns 缓存的位置信息，如果缓存失效则返回null
   */
  getCachedPosition(index) {
    const cached = this.positionCache.get(index);
    if (!cached)
      return null;
    const now = Date.now();
    if (now - cached.timestamp > this.CACHE_VALIDITY_MS) {
      this.positionCache.delete(index);
      return null;
    }
    return { top: cached.top, bottom: cached.bottom };
  }
  /**
   * 缓存节点的位置信息
   * @param index - 节点索引
   * @param rect - getBoundingClientRect结果
   */
  cachePosition(index, rect) {
    this.positionCache.set(index, {
      top: rect.top,
      bottom: rect.bottom,
      timestamp: Date.now()
    });
  }
  /**
   * 根据当前滚动位置更新当前索引
   * 优化逻辑：实时检测 DOM 位置，找到视口中最相关的 Prompt
   * @param scrollY - 当前滚动位置（window.scrollY）
   */
  updateCurrentIndexByScroll(scrollY) {
    if (this.items.length === 0) {
      return;
    }
    const windowHeight = window.innerHeight;
    const viewportCenter = windowHeight / 2;
    let activeIndex = 0;
    for (let i = 0; i < this.items.length; i++) {
      const node = this.items[i].promptNode;
      if (!node)
        continue;
      let cachedPos = this.getCachedPosition(i);
      let rectTop;
      if (cachedPos) {
        rectTop = cachedPos.top;
      } else {
        const rect = node.getBoundingClientRect();
        this.cachePosition(i, rect);
        rectTop = rect.top;
      }
      if (rectTop < viewportCenter) {
        activeIndex = i;
      } else {
        break;
      }
    }
    if (this.currentIndex !== activeIndex) {
      this.currentIndex = activeIndex;
    }
  }
  /**
   * 检查是否需要刷新对话列表
   * 如果页面上的对话数量发生变化，返回 true
   */
  needsRefresh() {
    if (this.adapter.getPromptCount) {
      return this.adapter.getPromptCount(this.root) !== this.items.length;
    }
    const currentPairs = this.adapter.getPromptAnswerPairs(this.root);
    return currentPairs.length !== this.items.length;
  }
};

// src/content/store/pinnedStore.ts
var PinnedStore = {
  /**
   * Storage Key Prefix
   */
  KEY_PREFIX: "llm-nav-pinned:",
  /**
   * Load pinned nodes for a specific conversation
   * @param conversationId 
   * @returns Promise<Set<string>> Set of pinned node IDs
   */
  async loadPinned(conversationId) {
    if (!conversationId)
      return /* @__PURE__ */ new Set();
    const key = this.KEY_PREFIX + conversationId;
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(key, (result) => {
          if (chrome.runtime.lastError) {
            resolve(/* @__PURE__ */ new Set());
            return;
          }
          const pinnedList = result[key] || [];
          resolve(new Set(pinnedList));
        });
      } catch (e) {
        resolve(/* @__PURE__ */ new Set());
      }
    });
  },
  /**
   * Toggle pinned state for a node
   * @param conversationId 
   * @param nodeId 
   * @returns Promise<boolean> New pinned state (true=pinned, false=unpinned)
   */
  async togglePinned(conversationId, nodeId) {
    if (!conversationId || !nodeId)
      return false;
    const currentPinned = await this.loadPinned(conversationId);
    let isPinned = false;
    if (currentPinned.has(nodeId)) {
      currentPinned.delete(nodeId);
      isPinned = false;
    } else {
      currentPinned.add(nodeId);
      isPinned = true;
    }
    await this.savePinned(conversationId, currentPinned);
    return isPinned;
  },
  /**
   * Save pinned nodes
   */
  async savePinned(conversationId, pinnedSet) {
    const key = this.KEY_PREFIX + conversationId;
    const pinnedList = Array.from(pinnedSet);
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set({ [key]: pinnedList }, () => {
          if (chrome.runtime.lastError) {
          }
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }
};

// src/content/navigation/themes.ts
var themes = {
  light: {
    name: "\u4EAE\u8272",
    activeColor: "#29B6F6",
    // 浅蓝
    activeShadow: "rgba(41, 182, 246, 0.5)",
    defaultNodeColor: "#dbdbdb",
    // 浅灰色
    timelineBarColor: "rgba(150, 150, 150, 0.3)",
    pinnedColor: "#0277BD",
    // 深蓝
    tooltipBackgroundColor: "rgba(255, 255, 255, 0.95)",
    tooltipTextColor: "#000000"
    // 黑色
  },
  dark: {
    name: "\u6697\u8272",
    activeColor: "#E0E0E0",
    // 亮灰 (选中)
    activeShadow: "rgba(255, 255, 255, 0.3)",
    defaultNodeColor: "#FFFFFF",
    // 白色 (默认)
    timelineBarColor: "rgba(255, 255, 255, 0.2)",
    pinnedColor: "#FF9800",
    // 橙色 (暗色下依然醒目)
    tooltipBackgroundColor: "rgba(50, 50, 50, 0.95)",
    tooltipTextColor: "#FFFFFF"
  },
  blue: {
    name: "\u5929\u84DD\u8272",
    activeColor: "#2196F3",
    // 鲜亮蓝
    activeShadow: "rgba(33, 150, 243, 0.5)",
    defaultNodeColor: "#90CAF9",
    // 浅蓝
    timelineBarColor: "rgba(33, 150, 243, 0.3)",
    pinnedColor: "#0D47A1",
    // 深蓝 (重点)
    tooltipBackgroundColor: "rgba(227, 242, 253, 0.95)",
    // 极浅蓝
    tooltipTextColor: "#0D47A1"
    // 深蓝
  },
  lavender: {
    name: "\u85B0\u8863\u8349",
    activeColor: "#9C88FF",
    // 紫色
    activeShadow: "rgba(156, 136, 255, 0.5)",
    defaultNodeColor: "#D1C4E9",
    // 浅紫
    timelineBarColor: "rgba(156, 136, 255, 0.3)",
    pinnedColor: "#673AB7",
    // 深紫 (重点)
    tooltipBackgroundColor: "rgba(237, 231, 246, 0.95)",
    // 极浅紫
    tooltipTextColor: "#4527A0"
    // 深紫
  },
  pink: {
    name: "\u7C89\u7EA2\u8272",
    activeColor: "#FF4081",
    // 亮粉
    activeShadow: "rgba(255, 64, 129, 0.5)",
    defaultNodeColor: "#F8BBD0",
    // 浅粉
    timelineBarColor: "rgba(255, 64, 129, 0.3)",
    pinnedColor: "#C2185B",
    // 深粉红 (重点)
    tooltipBackgroundColor: "rgba(252, 228, 236, 0.95)",
    // 极浅粉
    tooltipTextColor: "#880E4F"
    // 深粉
  },
  orange: {
    name: "\u6A58\u9EC4\u8272",
    activeColor: "#FF9800",
    // 橘黄
    activeShadow: "rgba(255, 152, 0, 0.5)",
    defaultNodeColor: "#FFE0B2",
    // 浅橘
    timelineBarColor: "rgba(255, 152, 0, 0.3)",
    pinnedColor: "#E65100",
    // 深橘红 (重点)
    tooltipBackgroundColor: "rgba(255, 243, 224, 0.95)",
    // 极浅橘
    tooltipTextColor: "#E65100"
    // 深橘
  }
};
function getSystemTheme() {
  if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
    return "dark";
  }
  return "light";
}
function resolveTheme(mode) {
  if (mode === "auto") {
    return getSystemTheme();
  }
  if (!themes[mode]) {
    return "light";
  }
  return mode;
}
var DEFAULT_THEME_MODE = "auto";

// src/content/navigation/rightSideTimelineNavigator.ts
var RightSideTimelineNavigator = class {
  constructor() {
    this.nodes = [];
    this.items = [];
    this.activeIndex = 0;
    this.onClickCallback = null;
    this.resizeObserver = null;
    this.conversationId = null;
    this.pinnedNodes = /* @__PURE__ */ new Set();
    // 当前主题
    this.currentTheme = themes.light;
    // 防止 ResizeObserver 无限循环的标志
    this.isUpdatingPositions = false;
    const savedTheme = localStorage.getItem("llm_nav_theme_cache");
    if (savedTheme && themes[savedTheme]) {
      this.currentTheme = themes[savedTheme];
    }
    this.container = this.createContainer();
    this.timelineBar = this.createTimelineBar();
    this.tooltip = this.createTooltip();
    this.container.appendChild(this.timelineBar);
    document.body.appendChild(this.container);
    document.body.appendChild(this.tooltip);
    this.resizeObserver = new ResizeObserver(() => {
      if (!this.isUpdatingPositions) {
        this.updateNodePositions();
      }
    });
    this.resizeObserver.observe(this.container);
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
    });
  }
  /**
   * 设置主题模式
   */
  setTheme(mode) {
    const themeType = resolveTheme(mode);
    this.currentTheme = themes[themeType];
    localStorage.setItem("llm_nav_theme_cache", themeType);
    this.timelineBar.style.backgroundColor = this.currentTheme.timelineBarColor;
    this.tooltip.style.backgroundColor = this.currentTheme.tooltipBackgroundColor;
    this.tooltip.style.color = this.currentTheme.tooltipTextColor;
    this.nodes.forEach((node, index) => {
      this.updateNodeStyle(node, index);
    });
  }
  /**
   * 设置当前对话 ID 并加载标记状态
   */
  async setConversationId(id) {
    this.conversationId = id;
    this.pinnedNodes = await PinnedStore.loadPinned(id);
    this.nodes.forEach((node, index) => {
      this.updateNodeStyle(node, index);
    });
  }
  /**
   * 创建主容器
   */
  createContainer() {
    const container = document.createElement("div");
    container.id = "llm-timeline-navigator";
    Object.assign(container.style, {
      position: "fixed",
      right: "20px",
      top: "50%",
      transform: "translateY(-50%)",
      width: "40px",
      height: "80vh",
      maxHeight: "800px",
      zIndex: "2147483647",
      // 使用最大层级，但避免影响其他功能
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "flex-start",
      pointerEvents: "none"
    });
    return container;
  }
  /**
   * 创建时间线竖线
   */
  createTimelineBar() {
    const bar = document.createElement("div");
    bar.className = "timeline-bar";
    Object.assign(bar.style, {
      position: "absolute",
      left: "50%",
      top: "0",
      width: "2px",
      height: "100%",
      backgroundColor: this.currentTheme.timelineBarColor,
      // 使用主题色
      transform: "translateX(-50%)",
      pointerEvents: "none",
      transition: "background-color 0.3s ease"
    });
    return bar;
  }
  /**
   * 创建 tooltip（用于 hover 显示 prompt 内容）
   */
  createTooltip() {
    const tooltip = document.createElement("div");
    tooltip.id = "llm-timeline-tooltip";
    tooltip.style.display = "none";
    Object.assign(tooltip.style, {
      position: "fixed",
      maxWidth: "200px",
      // 缩窄宽度
      padding: "8px 12px",
      backgroundColor: this.currentTheme.tooltipBackgroundColor,
      // 使用主题色
      color: this.currentTheme.tooltipTextColor,
      // 使用主题色
      fontSize: "12px",
      lineHeight: "1.4",
      borderRadius: "6px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.15)",
      zIndex: "9999",
      pointerEvents: "none",
      wordWrap: "break-word",
      whiteSpace: "pre-wrap",
      // 限制显示两行
      display: "-webkit-box",
      webkitLineClamp: "2",
      webkitBoxOrient: "vertical",
      overflow: "hidden"
    });
    return tooltip;
  }
  /**
   * 显示 tooltip
   */
  showTooltip(text, nodeElement) {
    const displayText = text.length > 80 ? text.substring(0, 80) + "..." : text;
    this.tooltip.textContent = displayText;
    this.tooltip.style.display = "block";
    const rect = nodeElement.getBoundingClientRect();
    const gap = 10;
    let left = rect.left - this.tooltip.offsetWidth - gap;
    let top = rect.top + rect.height / 2 - this.tooltip.offsetHeight / 2;
    if (left < 10) {
      left = rect.right + gap;
    }
    if (top < 10)
      top = 10;
    if (top + this.tooltip.offsetHeight > window.innerHeight - 10) {
      top = window.innerHeight - this.tooltip.offsetHeight - 10;
    }
    this.tooltip.style.left = `${left}px`;
    this.tooltip.style.top = `${top}px`;
  }
  /**
   * 隐藏 tooltip
   */
  hideTooltip() {
    this.tooltip.style.display = "none";
  }
  /**
   * 更新单个节点的样式（包含 Active 和 Pinned 状态）
   */
  updateNodeStyle(node, index) {
    const isActive = index === this.activeIndex;
    const isPinned = this.pinnedNodes.has(String(index));
    node.style.transition = "all 0.2s ease";
    if (isActive) {
      node.style.transform = "translate(-50%, -50%) scale(1.4)";
      node.style.zIndex = "10";
      node.style.boxShadow = `0 0 10px ${this.currentTheme.activeShadow}`;
      node.style.border = "3px solid #fff";
      if (isPinned) {
        node.style.backgroundColor = this.currentTheme.pinnedColor;
      } else {
        node.style.backgroundColor = this.currentTheme.activeColor;
      }
    } else {
      node.style.transform = "translate(-50%, -50%) scale(1)";
      node.style.zIndex = "1";
      node.style.boxShadow = "none";
      node.style.border = "2px solid #fff";
      if (isPinned) {
        node.style.backgroundColor = this.currentTheme.pinnedColor;
        node.style.transform = "translate(-50%, -50%) scale(1.2)";
      } else {
        node.style.backgroundColor = this.currentTheme.defaultNodeColor;
        node.style.transform = "translate(-50%, -50%) scale(1)";
      }
    }
  }
  /**
   * 创建单个节点
   */
  createNode(item, index) {
    const node = document.createElement("div");
    node.className = "timeline-node";
    node.dataset.index = String(index);
    Object.assign(node.style, {
      position: "absolute",
      left: "50%",
      width: "12px",
      height: "12px",
      borderRadius: "50%",
      cursor: "pointer",
      transform: "translate(-50%, -50%)",
      pointerEvents: "auto",
      overflow: "hidden"
      // 确保内部填充层不溢出
    });
    const fillLayer = document.createElement("div");
    fillLayer.className = "fill-layer";
    Object.assign(fillLayer.style, {
      position: "absolute",
      top: "0",
      left: "0",
      width: "100%",
      height: "100%",
      backgroundColor: this.currentTheme.pinnedColor,
      // 初始色为主题重点色
      borderRadius: "50%",
      transform: "scale(0)",
      // 默认隐藏
      transition: "transform 200ms ease-out",
      // 默认快速回退
      pointerEvents: "none",
      zIndex: "0"
    });
    node.appendChild(fillLayer);
    this.updateNodeStyle(node, index);
    let pressTimer = null;
    let isLongPress = false;
    const startPress = () => {
      isLongPress = false;
      const isAlreadyPinned = this.pinnedNodes.has(String(index));
      if (isAlreadyPinned) {
        fillLayer.style.backgroundColor = "#E0E0E0";
      } else {
        fillLayer.style.backgroundColor = this.currentTheme.pinnedColor;
      }
      fillLayer.style.transition = "transform 500ms linear";
      fillLayer.style.transform = "scale(1)";
      pressTimer = setTimeout(async () => {
        isLongPress = true;
        if (this.conversationId) {
          const nodeId = String(index);
          const newPinnedState = await PinnedStore.togglePinned(this.conversationId, nodeId);
          if (newPinnedState) {
            this.pinnedNodes.add(nodeId);
          } else {
            this.pinnedNodes.delete(nodeId);
          }
          this.updateNodeStyle(node, index);
          if (navigator.vibrate)
            navigator.vibrate(50);
        }
      }, 500);
    };
    const cancelPress = () => {
      if (pressTimer) {
        clearTimeout(pressTimer);
        pressTimer = null;
      }
      fillLayer.style.transition = "transform 200ms ease-out";
      fillLayer.style.transform = "scale(0)";
    };
    node.addEventListener("mousedown", startPress);
    node.addEventListener("touchstart", startPress, { passive: true });
    node.addEventListener("mouseup", cancelPress);
    node.addEventListener("mouseleave", cancelPress);
    node.addEventListener("touchend", cancelPress);
    node.addEventListener("mouseenter", () => {
      if (index !== this.activeIndex) {
        node.style.transform = "translate(-50%, -50%) scale(1.2)";
      }
      if (this.items[index]) {
        this.showTooltip(this.items[index].promptText, node);
      }
    });
    node.addEventListener("mouseleave", () => {
      this.updateNodeStyle(node, index);
      this.hideTooltip();
    });
    node.addEventListener("click", (e) => {
      if (isLongPress) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      const clickedIndex = parseInt(node.dataset.index || "0");
      if (this.onClickCallback) {
        this.onClickCallback(clickedIndex);
      }
    });
    return node;
  }
  /**
   * 初始化或更新时间线（传入所有对话条目）
   * 采用增量更新策略，实现平滑动画
   */
  init(items) {
    this.items = items;
    const newCount = items.length;
    const currentCount = this.nodes.length;
    if (newCount === 0) {
      this.nodes.forEach((node) => node.remove());
      this.nodes = [];
      return;
    }
    if (newCount < currentCount) {
      for (let i = newCount; i < currentCount; i++) {
        this.nodes[i].remove();
      }
      this.nodes.length = newCount;
    }
    items.forEach((item, index) => {
      if (index < this.nodes.length) {
        this.updateNodeStyle(this.nodes[index], index);
      } else {
        const node = this.createNode(item, index);
        node.style.opacity = "0";
        node.style.transform = "translate(-50%, -50%) scale(0)";
        this.container.appendChild(node);
        this.nodes.push(node);
        requestAnimationFrame(() => {
          node.style.opacity = "1";
          this.updateNodeStyle(node, index);
        });
      }
    });
    this.updateNodePositions();
  }
  /**
   * 更新所有节点的位置
   * 采用"等间距分布"策略 (Even Distribution)：
   * - 第一个节点固定在顶部 (Padding 位置)
   * - 最后一个节点固定在底部 (ContainerHeight - Padding)
   * - 中间节点均匀分布
   * - 这种方式类似"气泡"效果：新节点加入底部，旧节点自动向上挤压调整，且不再依赖页面 scrollHeight，彻底解决节点不可见问题
   */
  updateNodePositions() {
    if (this.isUpdatingPositions)
      return;
    this.isUpdatingPositions = true;
    try {
      const count = this.items.length;
      if (count === 0)
        return;
      const containerHeight = this.container.clientHeight;
      if (containerHeight === 0)
        return;
      const padding = 30;
      const usableHeight = containerHeight - padding * 2;
      this.items.forEach((item, index) => {
        const node = this.nodes[index];
        if (!node)
          return;
        let topPosition = padding;
        if (count === 1) {
          topPosition = padding;
        } else {
          const ratio = index / (count - 1);
          topPosition = padding + ratio * usableHeight;
        }
        node.style.top = `${topPosition}px`;
      });
    } finally {
      this.isUpdatingPositions = false;
    }
  }
  /**
   * 刷新节点位置（当窗口 resize 或内容变化时调用）
   */
  refreshPositions() {
    this.updateNodePositions();
  }
  /**
   * 更新当前激活的节点
   */
  updateActiveIndex(index) {
    if (index < 0 || index >= this.nodes.length) {
      return;
    }
    if (this.activeIndex >= 0 && this.activeIndex < this.nodes.length) {
      const oldIndex = this.activeIndex;
      this.activeIndex = -1;
      this.updateNodeStyle(this.nodes[oldIndex], oldIndex);
    }
    this.activeIndex = index;
    this.updateNodeStyle(this.nodes[index], index);
  }
  /**
   * 注册节点点击回调
   */
  onNodeClick(callback) {
    this.onClickCallback = callback;
  }
  /**
   * 显示时间线
   */
  show() {
    this.container.style.display = "flex";
  }
  /**
   * 隐藏时间线
   */
  hide() {
    this.container.style.display = "none";
  }
  /**
   * 切换显示/隐藏
   */
  toggle() {
    if (this.container.style.display === "none") {
      this.show();
    } else {
      this.hide();
    }
  }
  /**
   * 切换当前节点的标记状态
   */
  async togglePinnedCurrent() {
    if (!this.conversationId || this.activeIndex < 0 || this.activeIndex >= this.nodes.length) {
      return;
    }
    const index = this.activeIndex;
    const nodeId = String(index);
    const newPinnedState = await PinnedStore.togglePinned(this.conversationId, nodeId);
    if (newPinnedState) {
      this.pinnedNodes.add(nodeId);
    } else {
      this.pinnedNodes.delete(nodeId);
    }
    this.updateNodeStyle(this.nodes[index], index);
    if (navigator.vibrate)
      navigator.vibrate(50);
  }
  /**
   * 销毁时间线
   */
  destroy() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    this.container.remove();
    this.tooltip.remove();
  }
};

// src/content/navigation/scrollAndHighlight.ts
var HIGHLIGHT_CLASS = "llm-answer-nav-highlight";
var currentHighlightedNode = null;
var stylesInjected = false;
var cachedThemeMode = null;
var cachedThemeType = null;
async function injectStyles(forceUpdate = false) {
  try {
    if (cachedThemeMode === null) {
      const result = await chrome.storage.sync.get("ui_theme");
      cachedThemeMode = result.ui_theme || DEFAULT_THEME_MODE;
    }
  } catch (error) {
    cachedThemeMode = DEFAULT_THEME_MODE;
  }
  const actualTheme = resolveTheme(cachedThemeMode || DEFAULT_THEME_MODE);
  if (!forceUpdate && stylesInjected && cachedThemeType === actualTheme) {
    return;
  }
  cachedThemeType = actualTheme;
  const theme = themes[actualTheme];
  let style = document.getElementById("llm-answer-nav-styles");
  if (!style) {
    style = document.createElement("style");
    style.id = "llm-answer-nav-styles";
    document.head.appendChild(style);
  }
  style.textContent = `
    .${HIGHLIGHT_CLASS} {
      position: relative;
      animation: llm-nav-highlight-pulse 1s ease-in-out;
    }
    
    .${HIGHLIGHT_CLASS}::before {
      content: '';
      position: absolute;
      top: -8px;
      left: -8px;
      right: -8px;
      bottom: -8px;
      border: 3px solid ${theme.highlightBorder};
      border-radius: 8px;
      pointer-events: none;
      animation: llm-nav-border-fade 2s ease-in-out forwards;
    }
    
    @keyframes llm-nav-highlight-pulse {
      0%, 100% {
        background-color: transparent;
      }
      50% {
        background-color: ${theme.highlightBackground};
      }
    }
    
    @keyframes llm-nav-border-fade {
      0% {
        opacity: 1;
        border-width: 3px;
      }
      100% {
        opacity: 0.3;
        border-width: 2px;
      }
    }
  `;
  stylesInjected = true;
}
function scrollToAnswer(node, topOffset = 80) {
  if (!node) {
    return;
  }
  try {
    node.scrollIntoView({
      behavior: "smooth",
      block: "start",
      inline: "nearest"
    });
    setTimeout(() => {
      const currentScroll = window.scrollY;
      if (currentScroll > topOffset) {
        window.scrollTo({
          top: currentScroll - topOffset,
          behavior: "smooth"
        });
      }
    }, 100);
  } catch (error) {
    try {
      const rect = node.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const targetPosition = rect.top + scrollTop - topOffset;
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth"
      });
    } catch (backupError) {
    }
  }
}
async function highlightAnswer(node) {
  if (!node)
    return;
  await injectStyles();
  if (currentHighlightedNode && currentHighlightedNode !== node) {
    removeHighlight(currentHighlightedNode);
  }
  node.classList.add(HIGHLIGHT_CLASS);
  currentHighlightedNode = node;
  setTimeout(() => {
  }, 2e3);
}
function removeHighlight(node) {
  if (!node)
    return;
  node.classList.remove(HIGHLIGHT_CLASS);
}
if (chrome?.storage?.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "sync" && changes.ui_theme) {
      cachedThemeMode = changes.ui_theme.newValue || DEFAULT_THEME_MODE;
      injectStyles(true);
    }
  });
}
function scrollToAndHighlight(node, topOffset = 80) {
  if (!node)
    return;
  scrollToAnswer(node, topOffset);
  setTimeout(() => {
    highlightAnswer(node);
  }, 300);
}

// src/content/index.ts
var indexManager = null;
var timelineNavigator = null;
var isInitializing = false;
var initPromise = null;
var isListLocked = false;
var isManualScrolling = false;
var contentMutationObserver = null;
var currentInitId = 0;
var cachedSettings = null;
async function getSettings() {
  if (cachedSettings)
    return cachedSettings;
  cachedSettings = await chrome.storage.sync.get([
    "custom_urls",
    "enable_chatgpt",
    "enable_claude",
    "enable_gemini",
    "enable_deepseek",
    "ui_theme"
  ]);
  return cachedSettings;
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync") {
    if (cachedSettings) {
      for (const key in changes) {
        cachedSettings[key] = changes[key].newValue;
      }
    }
    if (changes.ui_theme && timelineNavigator) {
      timelineNavigator.setTheme(changes.ui_theme.newValue || "auto");
    }
  }
});
function debounce(func, wait) {
  let timeout = null;
  return function(...args) {
    if (timeout)
      clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}
function navigateToAnswer(index) {
  if (!indexManager) {
    return;
  }
  indexManager.setScrollUpdateEnabled(false);
  isManualScrolling = true;
  indexManager.setCurrentIndex(index);
  const node = indexManager.getCurrentNode();
  if (node) {
    scrollToAndHighlight(node);
  }
  updateUI();
  const restoreScrollTracking = () => {
    if (!indexManager)
      return;
    isManualScrolling = false;
    indexManager.setScrollUpdateEnabled(true);
    cleanupListeners();
  };
  const userInteractionEvents = ["wheel", "touchmove", "keydown", "mousedown"];
  const cleanupListeners = () => {
    userInteractionEvents.forEach((event) => {
      window.removeEventListener(event, restoreScrollTracking, { capture: true });
    });
  };
  userInteractionEvents.forEach((event) => {
    window.addEventListener(event, restoreScrollTracking, { capture: true, passive: true });
  });
  setTimeout(() => {
    if (isManualScrolling) {
      restoreScrollTracking();
    }
  }, 1e3);
}
function navigateToPrev() {
  if (!indexManager || indexManager.getTotalCount() === 0) {
    return;
  }
  const currentIndex = indexManager.getCurrentIndex();
  const targetIndex = Math.max(0, currentIndex - 1);
  navigateToAnswer(targetIndex);
}
function navigateToNext() {
  if (!indexManager || indexManager.getTotalCount() === 0) {
    return;
  }
  const currentIndex = indexManager.getCurrentIndex();
  const total = indexManager.getTotalCount();
  if (currentIndex < total - 1) {
    navigateToAnswer(currentIndex + 1);
  }
}
function updateUI() {
  if (timelineNavigator && indexManager) {
    timelineNavigator.updateActiveIndex(indexManager.getCurrentIndex());
  }
}
var handleResize = debounce(() => {
  if (indexManager && timelineNavigator) {
    indexManager.refresh();
    timelineNavigator.refreshPositions();
  }
}, 300);
var handleScroll = debounce(() => {
  if (isManualScrolling) {
    return;
  }
}, 100);
function clearUI() {
  currentInitId++;
  if (timelineNavigator) {
    timelineNavigator.destroy();
    timelineNavigator = null;
  }
  if (contentMutationObserver) {
    contentMutationObserver.disconnect();
    contentMutationObserver = null;
  }
  document.removeEventListener("scroll", handleScroll, { capture: true });
  window.removeEventListener("resize", handleResize);
  indexManager = null;
}
function getConversationId() {
  const pathname = window.location.pathname;
  const matchC = pathname.match(/\/c\/([a-zA-Z0-9-]+)/);
  if (matchC && matchC[1]) {
    return matchC[1];
  }
  const matchS = pathname.match(/\/s\/([a-zA-Z0-9-]+)/);
  if (matchS && matchS[1]) {
    return matchS[1];
  }
  return pathname === "/" ? "new-chat" : pathname;
}
function initTimelineNavigator() {
  if (!indexManager)
    return;
  if (!timelineNavigator) {
    timelineNavigator = new RightSideTimelineNavigator();
    timelineNavigator.onNodeClick((itemIndex) => {
      navigateToAnswer(itemIndex);
    });
  }
  const conversationId = getConversationId();
  timelineNavigator.setConversationId(conversationId);
  const theme = cachedSettings?.ui_theme || "auto";
  timelineNavigator.setTheme(theme);
  const items = indexManager.getItems();
  timelineNavigator.init(items);
  timelineNavigator.updateActiveIndex(indexManager.getCurrentIndex());
}
async function init() {
  if (isInitializing && initPromise) {
    return initPromise;
  }
  if (isInitializing) {
    return;
  }
  const myInitId = ++currentInitId;
  initPromise = (async () => {
    clearUI();
    const executionId = currentInitId;
    isInitializing = true;
    try {
      const settings = await getSettings();
      if (executionId !== currentInitId)
        return;
      const customUrls = settings.custom_urls || [];
      const adapter = getActiveAdapter(window.location, customUrls);
      if (!adapter) {
        if (executionId === currentInitId)
          isInitializing = false;
        return;
      }
      let isEnabled = true;
      if (adapter.name === "ChatGPT") {
        isEnabled = settings.enable_chatgpt !== false;
      } else if (adapter.name === "Claude") {
        isEnabled = settings.enable_claude !== false;
      } else if (adapter.name === "Gemini") {
        isEnabled = settings.enable_gemini !== false;
      } else if (adapter.name === "DeepSeek") {
        isEnabled = settings.enable_deepseek !== false;
      }
      if (!isEnabled) {
        if (executionId === currentInitId)
          isInitializing = false;
        return;
      }
      const mainElement = document.querySelector("main");
      const rootElement = mainElement || document.body;
      indexManager = new AnswerIndexManager(adapter, rootElement);
      indexManager.onIndexChange((index) => {
        updateUI();
      });
      const totalCount = indexManager.getTotalCount();
      if (totalCount > 0) {
        isListLocked = true;
        indexManager.updateCurrentIndexByScroll(window.scrollY);
      } else {
        isListLocked = false;
      }
      if (totalCount > 0) {
        initTimelineNavigator();
      }
      document.addEventListener("scroll", handleScroll, { passive: true, capture: true });
      window.addEventListener("resize", handleResize, { passive: true });
      if (contentMutationObserver) {
        contentMutationObserver.disconnect();
        contentMutationObserver = null;
      }
      contentMutationObserver = new MutationObserver(debounce(() => {
        if (executionId !== currentInitId)
          return;
        if (!indexManager)
          return;
        if (isListLocked) {
          if (indexManager.needsRefresh()) {
            const oldCount = indexManager.getTotalCount();
            indexManager.refresh();
            const newCount = indexManager.getTotalCount();
            if (newCount > oldCount) {
              initTimelineNavigator();
              indexManager.setCurrentIndex(newCount - 1);
              updateUI();
            }
          }
          return;
        }
        if (indexManager.getTotalCount() === 0) {
          if (indexManager.needsRefresh()) {
            indexManager.refresh();
            const newCount = indexManager.getTotalCount();
            if (newCount > 0) {
              isListLocked = true;
              indexManager.updateCurrentIndexByScroll(window.scrollY);
              initTimelineNavigator();
              updateUI();
            }
          }
        }
      }, 1e3));
      contentMutationObserver.observe(rootElement, {
        childList: true,
        subtree: true
      });
      if (totalCount === 0) {
        setTimeout(() => {
          if (executionId !== currentInitId)
            return;
          if (!isListLocked) {
            isListLocked = true;
          }
        }, 5e3);
      }
    } finally {
      isInitializing = false;
      initPromise = null;
    }
  })();
  return initPromise;
}
var lastUrl = window.location.href;
function handleUrlChange() {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    lastUrl = currentUrl;
    clearUI();
    isListLocked = false;
    setTimeout(() => {
      init();
    }, 1e3);
  }
}
setInterval(handleUrlChange, 1e3);
window.addEventListener("popstate", () => {
  setTimeout(handleUrlChange, 100);
});
document.addEventListener("click", () => {
  setTimeout(handleUrlChange, 200);
}, { capture: true, passive: true });
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "LLM_NAV_PREV_ANSWER") {
    navigateToPrev();
    sendResponse({ success: true });
  } else if (message.type === "LLM_NAV_NEXT_ANSWER") {
    navigateToNext();
    sendResponse({ success: true });
  } else if (message.type === "LLM_NAV_TOGGLE_UI") {
    if (timelineNavigator) {
      timelineNavigator.toggle();
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: "Timeline not initialized" });
    }
  } else if (message.type === "LLM_NAV_UPDATE_THEME") {
    if (timelineNavigator) {
      timelineNavigator.setTheme(message.theme);
    }
    sendResponse({ success: true });
  } else if (message.type === "LLM_NAV_TOGGLE_PIN") {
    if (timelineNavigator) {
      timelineNavigator.togglePinnedCurrent();
    }
    sendResponse({ success: true });
  }
});
