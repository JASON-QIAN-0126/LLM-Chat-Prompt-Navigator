// src/options/index.ts
var CONFIG_KEYS = {
  ENABLE_CHATGPT: "enable_chatgpt",
  ENABLE_CLAUDE: "enable_claude",
  ENABLE_GEMINI: "enable_gemini",
  ENABLE_DEEPSEEK: "enable_deepseek",
  UI_THEME: "ui_theme",
  CUSTOM_URLS: "custom_urls"
};
async function loadSettings() {
  try {
    const result = await chrome.storage.sync.get([
      CONFIG_KEYS.ENABLE_CHATGPT,
      CONFIG_KEYS.ENABLE_CLAUDE,
      CONFIG_KEYS.ENABLE_GEMINI,
      CONFIG_KEYS.ENABLE_DEEPSEEK,
      CONFIG_KEYS.UI_THEME,
      CONFIG_KEYS.CUSTOM_URLS
    ]);
    const enableChatGPT = result[CONFIG_KEYS.ENABLE_CHATGPT] !== false;
    const enableClaude = result[CONFIG_KEYS.ENABLE_CLAUDE] !== false;
    const enableGemini = result[CONFIG_KEYS.ENABLE_GEMINI] !== false;
    const enableDeepSeek = result[CONFIG_KEYS.ENABLE_DEEPSEEK] !== false;
    const uiTheme = result[CONFIG_KEYS.UI_THEME] || "auto";
    const customUrls = result[CONFIG_KEYS.CUSTOM_URLS] || [];
    const setCheckbox = (id, checked) => {
      const checkbox = document.getElementById(id);
      if (checkbox)
        checkbox.checked = checked;
    };
    setCheckbox("enable-chatgpt", enableChatGPT);
    setCheckbox("enable-claude", enableClaude);
    setCheckbox("enable-gemini", enableGemini);
    setCheckbox("enable-deepseek", enableDeepSeek);
    const themeSelect = document.getElementById("ui-theme");
    if (themeSelect) {
      themeSelect.value = uiTheme;
    }
    renderCustomUrls(customUrls);
  } catch (error) {
  }
}
function renderCustomUrls(urls) {
  const list = document.getElementById("custom-url-list");
  if (!list)
    return;
  list.innerHTML = "";
  urls.forEach((url, index) => {
    const li = document.createElement("li");
    Object.assign(li.style, {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "8px 12px",
      borderBottom: "1px solid #eee",
      background: "#f9f9f9",
      borderRadius: "4px",
      marginBottom: "5px"
    });
    const span = document.createElement("span");
    span.textContent = url;
    span.style.color = "#333";
    const btn = document.createElement("button");
    btn.textContent = "\u5220\u9664";
    Object.assign(btn.style, {
      padding: "4px 8px",
      background: "#ff4444",
      color: "white",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
      fontSize: "12px"
    });
    btn.onclick = () => {
      const newUrls = urls.filter((_, i) => i !== index);
      saveSetting(CONFIG_KEYS.CUSTOM_URLS, newUrls);
      renderCustomUrls(newUrls);
    };
    li.appendChild(span);
    li.appendChild(btn);
    list.appendChild(li);
  });
}
function addCustomUrl() {
  const input = document.getElementById("custom-url-input");
  const url = input.value.trim();
  if (!url)
    return;
  let domain = url;
  try {
    if (!url.startsWith("http")) {
      if (url.includes("/")) {
        domain = new URL("https://" + url).hostname;
      } else {
        domain = url;
      }
    } else {
      domain = new URL(url).hostname;
    }
  } catch (e) {
    alert("\u8BF7\u8F93\u5165\u6709\u6548\u7684\u57DF\u540D");
    return;
  }
  chrome.storage.sync.get([CONFIG_KEYS.CUSTOM_URLS], (result) => {
    const urls = result[CONFIG_KEYS.CUSTOM_URLS] || [];
    if (!urls.includes(domain)) {
      const newUrls = [...urls, domain];
      saveSetting(CONFIG_KEYS.CUSTOM_URLS, newUrls);
      renderCustomUrls(newUrls);
      input.value = "";
    } else {
      alert("\u8BE5\u57DF\u540D\u5DF2\u5B58\u5728");
    }
  });
}
async function saveSetting(key, value) {
  try {
    await chrome.storage.sync.set({ [key]: value });
    showSaveStatus();
  } catch (error) {
  }
}
function showSaveStatus() {
  const status = document.getElementById("save-status");
  if (status) {
    status.classList.add("success");
    status.style.display = "block";
    setTimeout(() => {
      status.style.display = "none";
    }, 2e3);
  }
}
document.addEventListener("DOMContentLoaded", () => {
  loadSettings();
  const bindCheckbox = (id, key) => {
    const checkbox = document.getElementById(id);
    if (checkbox) {
      checkbox.addEventListener("change", (e) => {
        const target = e.target;
        saveSetting(key, target.checked);
      });
    }
  };
  bindCheckbox("enable-chatgpt", CONFIG_KEYS.ENABLE_CHATGPT);
  bindCheckbox("enable-claude", CONFIG_KEYS.ENABLE_CLAUDE);
  bindCheckbox("enable-gemini", CONFIG_KEYS.ENABLE_GEMINI);
  bindCheckbox("enable-deepseek", CONFIG_KEYS.ENABLE_DEEPSEEK);
  const themeSelect = document.getElementById("ui-theme");
  if (themeSelect) {
    themeSelect.addEventListener("change", (e) => {
      const target = e.target;
      saveSetting(CONFIG_KEYS.UI_THEME, target.value);
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              type: "LLM_NAV_UPDATE_THEME",
              theme: target.value
            }).catch(() => {
            });
          }
        });
      });
    });
  }
  const addBtn = document.getElementById("add-url-btn");
  if (addBtn) {
    addBtn.addEventListener("click", addCustomUrl);
  }
  const urlInput = document.getElementById("custom-url-input");
  if (urlInput) {
    urlInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        addCustomUrl();
      }
    });
  }
});
